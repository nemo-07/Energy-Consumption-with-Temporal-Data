import os
from flask import Flask, render_template, request
import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
from utils.data_processing import preprocess_data, df_to_X_y
from utils.visualization import (
    plot_actual_vs_predicted,
    plot_global_active_power,
    plot_carbon_footprint,
    load_global_active_power_data,
    carbon_footprint,
    plot_predictions2
)

app = Flask(__name__)

# Load the model
model_path = os.path.join('model', 'model_checkpoint.keras')
if not os.path.exists(model_path):
    raise FileNotFoundError(f"No file or directory found at {model_path}")

model = load_model(model_path)

# Load and preprocess data (example, adjust as per your actual preprocessing)
csv_path = r"C:\Users\infos\OneDrive\Desktop\GAIP\household_power_consumption_household_power_consumption.csv"
df = pd.read_csv(csv_path)
df = preprocess_data(df)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        threshold = float(request.form['threshold'])
        X_test, y_test = df_to_X_y(df)  # Adjust this based on your data preparation logic

        # Use your plot function to generate the DataFrame and plot
        predictions_df = plot_predictions2(model, X_test, y_test)

        # Prepare data for plotting
        actual_values = df['Global_active_power'].values
        timestamps = df.index.values

        # Plot actual vs predicted graph
        actual_vs_predicted_plot = plot_actual_vs_predicted(timestamps, actual_values, predictions_df['Global Active Power Predictions'].values)

        # Load global active power data for plotting
        global_active_power_data = load_global_active_power_data()
        global_active_power_plot = plot_global_active_power(global_active_power_data['Timestamp'], global_active_power_data['Global Active Power'])

        # Calculate and plot carbon footprint based on global active power data
        carbon_footprints, total_carbon_footprint = carbon_footprint(global_active_power_data['Global Active Power'])
        carbon_footprint_plot = plot_carbon_footprint(global_active_power_data['Timestamp'], carbon_footprints)

        return render_template('result.html', 
                               actual_vs_predicted_plot=actual_vs_predicted_plot,
                               global_active_power_plot=global_active_power_plot,
                               carbon_footprint_plot=carbon_footprint_plot,
                               threshold=threshold)

    except Exception as e:
        return render_template('error.html', error=str(e))
