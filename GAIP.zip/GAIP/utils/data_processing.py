import numpy as np
import pandas as pd
import warnings


def preprocess_data(df):
    global_active_power = df.pop('Global_active_power')
    global_reactive_power = df.pop('Global_reactive_power')
    df['Global_active_power'] = global_active_power
    df['Global_reactive_power'] = global_reactive_power

    try:
        # Convert 'Date' column to datetime if needed
        try:
            if 'Date' in df.columns:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)

            for col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        except Exception as e:
            pass


        df = df.dropna(subset=['Sub_metering_1', 'Sub_metering_2', 'Sub_metering_3'])

        temp = df['Sub_metering_1']
        temp_df = pd.DataFrame({'Sub_1': temp})
        temp_df.index = pd.to_datetime(temp_df.index)  # Ensure index is DateTimeIndex
        temp_df['Seconds'] = temp_df.index.map(pd.Timestamp.timestamp)
        day = 60*60*24
        year = 365.2425*day
        temp_df['Day sin'] = np.sin(temp_df['Seconds'] * (2 * np.pi / day))
        temp_df['Day cos'] = np.cos(temp_df['Seconds'] * (2 * np.pi / day))
        temp_df['Year sin'] = np.sin(temp_df['Seconds'] * (2 * np.pi / year))
        temp_df['Year cos'] = np.cos(temp_df['Seconds'] * (2 * np.pi / year))
        temp_df = temp_df.drop('Seconds', axis=1)

        v_temp_df = pd.concat([df['Global_active_power'], temp_df], axis=1)
        return v_temp_df

    except Exception as e:
        print(f"Error during data preprocessing: {e}")
        raise

def df_to_X_y(df, window_size=7):
    df_as_np = df.to_numpy()
    X = []
    y = []
    for i in range(len(df_as_np) - window_size):
        row = [r for r in df_as_np[i:i + window_size]]
        X.append(row)
        label = [df_as_np[i + window_size][0], df_as_np[i + window_size][1]]
        y.append(label)
    return np.array(X), np.array(y)

def carbon_footprint(global_active_power):
    emissions_factor = 0.5  # kg CO2 per kWh
    carbon_footprints = [power * emissions_factor for power in global_active_power]
    total_carbon_footprint = sum(carbon_footprints)
    return carbon_footprints, total_carbon_footprint
