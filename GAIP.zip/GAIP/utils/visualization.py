import matplotlib.pyplot as plt
import pandas as pd

def plot_predictions2(model, X, y, start=0, end=100):
    
    predictions = model.predict(X)
    p_preds, temp_preds = predictions[:, 0], predictions[:, 1]
    p_actuals, temp_actuals = y[:, 0], y[:, 1]
    df = pd.DataFrame(data={'Submetering sec 1 Predictions': temp_preds,
                            'Submetering sec 1 Actuals': temp_actuals,
                            'Global Active Power Predictions': p_preds,
                            'Global Active Power Actuals': p_actuals
                            })
    return df[start:end]


def plot_actual_vs_predicted(timestamps, actual_values, predictions):
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(timestamps, actual_values, label='Actual Global Active Power (kW)', color='blue')
    ax.plot(timestamps, predictions, label='Predicted Global Active Power (kW)', color='red')
    ax.set_xlabel('Timestamp')
    ax.set_ylabel('Global Active Power (kW)')
    ax.set_title('Actual vs Predicted Global Active Power')
    ax.legend()
    plt.grid(True)
    return fig

def plot_global_active_power(timestamps, global_active_power):
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(timestamps, global_active_power, label='Global Active Power (kW)', color='green')
    ax.set_xlabel('Timestamp')
    ax.set_ylabel('Global Active Power (kW)')
    ax.set_title('Global Active Power')
    ax.legend()
    plt.grid(True)
    return fig

def plot_carbon_footprint(timestamps, carbon_footprints):
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(timestamps, carbon_footprints, label='Carbon Footprint (kg CO2)', color='orange')
    ax.set_xlabel('Timestamp')
    ax.set_ylabel('Carbon Footprint (kg CO2)')
    ax.set_title('Carbon Footprint')
    ax.legend()
    plt.grid(True)
    return fig

def load_global_active_power_data():
    # Replace with actual loading logic
    return pd.DataFrame({
        'Timestamp': pd.date_range(start='2024-01-01', periods=100, freq='D'),
        'Global Active Power': pd.Series(range(100))
    })

def carbon_footprint(global_active_power):
    emissions_factor = 0.5  # kg CO2 per kWh
    carbon_footprints = [power * emissions_factor for power in global_active_power]
    total_carbon_footprint = sum(carbon_footprints)
    return carbon_footprints, total_carbon_footprint
