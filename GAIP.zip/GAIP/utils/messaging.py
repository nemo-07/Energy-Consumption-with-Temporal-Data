# utils/messaging.py

from twilio.rest import Client

def send_message(account_sid, auth_token, to_number, message_body):
    if not account_sid or not auth_token:
        raise ValueError("Missing Twilio Account SID or Auth Token")

    client = Client(account_sid, auth_token)
    message = client.messages.create(
        from_='+12073379400',  # Your Twilio phone number
        body=message_body,
        to=to_number
    )

    print(f"Message sent successfully. SID: {message.sid}")

def carbon_footprint(power_data):
    CO2_per_kWh = 0.5
    carbon_footprints = [power * CO2_per_kWh for power in power_data]
    total_carbon_footprint = sum(carbon_footprints)
    return carbon_footprints, total_carbon_footprint
